import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AssessmentProvider } from "./context/AssessmentContext";
import Layout from "./components/Layout";
import Dashboard from "./pages/Dashboard";
import Assessment from "./pages/Assessment";
import QuestionBank from "./pages/QuestionBank";
import Review from "./pages/Review";

export default function App() {
  return (
    <AssessmentProvider>
      <BrowserRouter>
        <Layout>
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/assessment" element={<Assessment />} />
            <Route path="/questions" element={<QuestionBank />} />
            <Route path="/review" element={<Review />} />
          </Routes>
        </Layout>
      </BrowserRouter>
    </AssessmentProvider>
  );
}
